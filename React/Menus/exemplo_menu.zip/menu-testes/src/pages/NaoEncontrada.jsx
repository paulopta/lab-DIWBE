const NaoEncontrada = () =>{
    return (<h1>Nao Encontrada</h1>);
}

export default NaoEncontrada;