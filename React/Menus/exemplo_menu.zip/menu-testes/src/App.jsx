import { createBrowserRouter, RouterProvider } from 'react-router-dom';

// 1. Importe as suas páginas (Componentes)
import {Layout} from './components/Layout';
import Home  from './pages/Home';
import Sobre from './pages/Sobre';
import Contato  from './pages/Contato';
import NaoEncontrada  from './pages/NaoEncontrada';

// 2. Defina a árvore de rotas
const router = createBrowserRouter([
  {
    path: "/",
    element: <Layout />, // Layout principal que abraça os filhos
    errorElement: <NaoEncontrada />, // Página de erro 404 se a rota não existir
    children: [
      {
        path: "/", // Rota inicial (Home)
        element: <Home />,
      },
      {
        path: "/sobre",
        element: <Sobre />,
      },
      {
        path: "/contato",
        element: <Contato />,
      },
    ],
  },
]);

// 3. Exporte o componente principal que providencia o roteamento
export default function App() {
  return <RouterProvider router={router} />;
}
