import { NavLink } from 'react-router-dom';
import './navbar.css';

export function Navbar() {
  return (
    <nav className="menu">
      <NavLink 
        to="/" 
        className={({ isActive }) => isActive ? 'link ativo' : 'link'}
      >
        Home
      </NavLink>
      
      <NavLink 
        to="/sobre" 
        className={({ isActive }) => isActive ? 'link ativo' : 'link'}
      >
        Sobre
      </NavLink>

      <NavLink 
        to="/contato" 
        className={({ isActive }) => isActive ? 'link ativo' : 'link'}
      >
        Contato
      </NavLink>
    </nav>
  );
}
