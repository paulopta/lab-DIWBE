import { Outlet } from 'react-router-dom';
import {Navbar}   from './Navbar'; 

export function Layout() {
  return (
    <>
      <Navbar /> {/* O seu menu NavLink fixo no topo */}
      <main style={{ padding: '20px' }}>
        <Outlet /> {/* Onde o conteúdo das páginas (Home, Sobre, etc.) vai renderizar */}
      </main>
    </>
  );
}
