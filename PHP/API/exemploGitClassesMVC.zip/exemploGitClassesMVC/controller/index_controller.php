<?php



require_once 'task_controller.php';

// Pega a ação enviada pela URL (ex: index.php?action=listar)
$action = isset($_GET['action']) ? $_GET['action'] : 'listar';

$controller = new TaskController();

// Verifica qual método chamar com base na ação
switch ($action) {
    case 'listar':
        $controller->listar();
        break;
    case 'cadastrar':
        $controller->cadastrar();
        break;
    case 'editar':
        $controller->editar();
        break;
    case 'deletar':
        $controller->deletar();
        break;
    default:
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Ação inválida']);
        break;
}