<?php

require_once '../model/task_model.php'; // Inclui a Model de tarefas

class TaskController
{
    private $model;

    public function __construct() {
        // Instancia a Model para ser usada nos métodos
        $this->model = new Task_model();
    }

    // Lista todas as tarefas
    public function listar() {
        $tarefas = $this->model->lista_tarefas();
        
        header('Content-Type: application/json');
        echo json_encode($tarefas);
    }

    // Cadastra uma nova tarefa
    public function cadastrar() {
        // Verifica se a requisição é POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // No PHP 5.6, usamos operador ternário ou isset para evitar avisos
            $title = isset($_POST['title']) ? $_POST['title'] : '';
            
            $resultado = $this->model->cadastra_tarefa($title);
            
            header('Content-Type: application/json');
            echo json_encode($resultado);
            exit;
        }
    }

    // Edita/Marca tarefa como concluída
    public function editar() {
        $id = isset($_POST['id']) ? $_POST['id'] : (isset($_GET['id']) ? $_GET['id'] : null);
        
        if ($id) {
            $resultado = $this->model->edita_tarefa($id);
            header('Content-Type: application/json');
            echo json_encode($resultado);
            exit;
        } else {
            header('Content-Type: application/json');
            echo json_encode(['error' => 'O ID da tarefa é obrigatório']);
            exit;
        }
    }

    // Deleta uma tarefa
    public function deletar() {
        $id = isset($_POST['id']) ? $_POST['id'] : (isset($_GET['id']) ? $_GET['id'] : null);
        
        if ($id) {
            $resultado = $this->model->deleta_tarefa($id);
            header('Content-Type: application/json');
            echo json_encode($resultado);
            exit;
        } else {
            header('Content-Type: application/json');
            echo json_encode(['error' => 'O ID da tarefa é obrigatório']);
            exit;
        }
    }
}

?>