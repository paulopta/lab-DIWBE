const ctrl_index = './controller/index_controller.php'; 

// Carrega as tarefas ao abrir a página
document.addEventListener('DOMContentLoaded', fetchTasks);

// 1. Listar tarefas
async function fetchTasks() {
    try {
        const response = await fetch(`${ctrl_index}?action=listar`);
        const tasks = await response.json();
        renderTasks(tasks);
    } catch (error) {
        console.log('Erro ao buscar tarefas:', error);
    }
}

// Renderiza as tarefas na tela (muda nada aqui)
function renderTasks(tasks) {
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = '';

    tasks.forEach(task => {
        const li = document.createElement('li');
        
        const titleSpan = document.createElement('span');
        titleSpan.textContent = task.title;
        if (Number(task.completed) === 1) {
            titleSpan.classList.add('completed');
        }

        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'actions';

        if (Number(task.completed) === 0) {
            const completeBtn = document.createElement('button');
            completeBtn.textContent = 'Concluir';
            completeBtn.className = 'btn-complete';
            completeBtn.onclick = () => completeTask(task.id);
            actionsDiv.appendChild(completeBtn);
        }

        const deleteBtn = document.createElement('button');
        deleteBtn.textContent = 'Excluir';
        deleteBtn.className = 'btn-delete';
        deleteBtn.onclick = () => deleteTask(task.id);
        actionsDiv.appendChild(deleteBtn);

        li.appendChild(titleSpan);
        li.appendChild(actionsDiv);
        taskList.appendChild(li);
    });
}

// 2. Criar tarefa (CORRIGIDO para usar ?action=cadastrar)
async function addTask() {
    const input = document.getElementById('taskTitle');
    const title = input.value.trim();

    if (!title) return;

    const formData = new FormData();
    formData.append('title', title);

    try {
        await fetch(`${ctrl_index}?action=cadastrar`, {
            method: 'POST',
            body: formData
        });
        input.value = '';
        fetchTasks();
    } catch (error) {
        console.log('Erro ao adicionar tarefa:', error);
    }
}

// 3. Atualizar/Concluir tarefa (CORRIGIDO para usar ?action=editar)
async function completeTask(id) {
    const formData = new FormData();
    formData.append('id', id);

    try {
        await fetch(`${ctrl_index}?action=editar`, {
            method: 'POST',
            body: formData
        });
        fetchTasks();
    } catch (error) {
        console.log('Erro ao concluir tarefa:', error);
    }
}

// 4. Apagar tarefa (CORRIGIDO para usar ?action=deletar)
async function deleteTask(id) {
    const formData = new FormData();
    formData.append('id', id);

    try {
        await fetch(`${ctrl_index}?action=deletar`, {
            method: 'POST',
            body: formData
        });
        fetchTasks();
    } catch (error) {
        console.log('Erro ao deletar tarefa:', error);
    }
}