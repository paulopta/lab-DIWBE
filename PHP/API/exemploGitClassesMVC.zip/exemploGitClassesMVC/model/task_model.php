<?php

require_once 'database.php';

class Task_model
{
    private $conn;

    public function __construct() {
        // Instancia a classe Connection e pega a propriedade conn
        $database = new Connection();
        $this->conn = $database->conn;
    }

    public function lista_tarefas()
    {
        try {
            $stmt = $this->conn->query('SELECT * FROM tasks');
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }

    public function cadastra_tarefa($title)
    {
        if (empty($title)) {
            return ['error' => 'O título da tarefa é obrigatório'];
        }

        try {
            $stmt = $this->conn->prepare('INSERT INTO tasks (title) VALUES (:title)');
            $stmt->bindParam(':title', $title);
            $stmt->execute();
            
            return [
                'id' => $this->conn->lastInsertId(),
                'title' => $title,
                'completed' => false
            ];
        } catch (PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }

    public function edita_tarefa($id)
    {
        if (empty($id)) {
            return ['error' => 'O ID da tarefa é obrigatório'];
        }

        try {
            $stmt = $this->conn->prepare('UPDATE tasks SET completed = 1 WHERE id = :id');
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            return ['success' => true];
        } catch (PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }

    public function deleta_tarefa($id)
    {
        if (empty($id)) {
            return ['error' => 'O ID da tarefa é obrigatório'];
        }

        try {
            $stmt = $this->conn->prepare('DELETE FROM tasks WHERE id = :id');
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            return ['success' => true];
        } catch (PDOException $e) {
            return ['error' => $e->getMessage()];
        }
    }
}

?>