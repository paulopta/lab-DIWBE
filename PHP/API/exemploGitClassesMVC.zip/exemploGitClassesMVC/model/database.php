<?php

class Connection
{
    public $conn; 
    private $host;
    private $db;
    private $port;
    private $user;
    private $pass;

    public function __construct() {
        $this->host = 'localhost';
        $this->db   = 'tasks';
        $this->port = 3306;
        $this->user = 'root';
        $this->pass = ''; // Corrigido para $this->pass

        try {
            // Corrigido para acessar via $this->
            $dsn = "mysql:host={$this->host};port={$this->port};dbname={$this->db};charset=utf8";
            $this->conn = new PDO($dsn, $this->user, $this->pass);
            
            // Configura o PDO para lançar exceções em caso de erro
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
        } catch(PDOException $e) {
            echo 'Erro na conexão com o banco de dados: ' . $e->getMessage();
            exit;
        }
    }

    /* SQL de criação da DATABASE
    CREATE TABLE tasks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        completed BOOLEAN NOT NULL DEFAULT 0
    );*/

}