const API_URL = './api'; // Altere se os arquivos PHP estiverem em uma subpasta (ex: './api')

        // Carrega as tarefas ao abrir a página
        document.addEventListener('DOMContentLoaded', fetchTasks);

        // 1. Listar tarefas (get_tasks.php)
        async function fetchTasks() {
            try {
                const response = await fetch(`${API_URL}/get_tasks.php`);
                const tasks = await response.json();
                renderTasks(tasks);
            } catch (error) {
                console.error('Erro ao buscar tarefas:', error);
            }
        }

        // Renderiza as tarefas na tela
        function renderTasks(tasks) {
            const taskList = document.getElementById('taskList');
            taskList.innerHTML = '';

            tasks.forEach(task => {
                const li = document.createElement('li');
                
                const titleSpan = document.createElement('span');
                titleSpan.textContent = task.title;
                if (Number(task.completed) === 1) {
                    titleSpan.classList.add('completed');
                }

                const actionsDiv = document.createElement('div');
                actionsDiv.className = 'actions';

                // Botão de Concluir (exibe apenas se não estiver concluída)
                if (Number(task.completed) === 0) {
                    const completeBtn = document.createElement('button');
                    completeBtn.textContent = 'Concluir';
                    completeBtn.className = 'btn-complete';
                    completeBtn.onclick = () => completeTask(task.id);
                    actionsDiv.appendChild(completeBtn);
                }

                // Botão de Deletar
                const deleteBtn = document.createElement('button');
                deleteBtn.textContent = 'Excluir';
                deleteBtn.className = 'btn-delete';
                deleteBtn.onclick = () => deleteTask(task.id);
                actionsDiv.appendChild(deleteBtn);

                li.appendChild(titleSpan);
                li.appendChild(actionsDiv);
                taskList.appendChild(li);
            });
        }

        // 2. Criar tarefa (add_task.php) usando FormData
        async function addTask() {
            const input = document.getElementById('taskTitle');
            const title = input.value.trim();

            if (!title) return;

            const formData = new FormData();
            formData.append('title', title);

            try {
                await fetch(`${API_URL}/add_task.php`, {
                    method: 'POST',
                    body: formData // O navegador define o Content-Type como multipart/form-data automaticamente
                });
                input.value = '';
                fetchTasks();
            } catch (error) {
                console.error('Erro ao adicionar tarefa:', error);
            }
        }

        // 3. Atualizar/Concluir tarefa (complete_task.php) usando FormData
        async function completeTask(id) {
            const formData = new FormData();
            formData.append('id', id);

            try {
                await fetch(`${API_URL}/complete_task.php`, {
                    method: 'POST',
                    body: formData
                });
                fetchTasks();
            } catch (error) {
                console.error('Erro ao concluir tarefa:', error);
            }
        }

        // 4. Apagar tarefa (delet_task.php) usando FormData
        async function deleteTask(id) {
            const formData = new FormData();
            formData.append('id', id);

            try {
                await fetch(`${API_URL}/delete_task.php`, {
                    method: 'POST',
                    body: formData
                });
                fetchTasks();
            } catch (error) {
                console.error('Erro ao deletar tarefa:', error);
            }
        }